#pragma once
#include <stdint.h>

#define DHT11 11
#define DHT22 22

class DHT {
public:
    DHT(uint8_t pin, uint8_t type, uint8_t count = 6) {}
    void begin() {}
    float readTemperature(bool isFahrenheit = false) { return 25.0f; }
    float readHumidity() { return 50.0f; }
};
