#pragma once
#include <stdint.h>
#include <stddef.h>

class TwoWire {
public:
    TwoWire() {}
    bool begin(int sda = -1, int scl = -1) { return true; }
    void beginTransmission(uint8_t addr) {}
    size_t write(uint8_t data) { return 1; }
    uint8_t endTransmission(bool sendStop = true) { return 0; }
    uint8_t requestFrom(uint8_t addr, uint8_t quantity, bool sendStop = true) { return quantity; }
    uint8_t read() { return 0; }
};

extern TwoWire Wire;
