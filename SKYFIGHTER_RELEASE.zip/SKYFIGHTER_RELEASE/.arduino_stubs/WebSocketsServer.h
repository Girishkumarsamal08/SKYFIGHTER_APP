#pragma once
#include "Arduino.h"

enum WStype_t {
    WStype_ERROR,
    WStype_DISCONNECTED,
    WStype_CONNECTED,
    WStype_TEXT,
    WStype_BIN,
    WStype_FRAGMENT_TEXT_START,
    WStype_FRAGMENT_BIN_START,
    WStype_FRAGMENT,
    WStype_FRAGMENT_FIN,
    WStype_PING,
    WStype_PONG
};

typedef void (*WebSocketServerEvent)(uint8_t num, WStype_t type, uint8_t * payload, size_t length);

class WebSocketsServer {
public:
    WebSocketsServer(uint16_t port) {}
    void begin() {}
    void loop() {}
    void onEvent(WebSocketServerEvent cb) {}
    bool broadcastTXT(const String& payload) { return true; }
    bool sendTXT(uint8_t num, const String& payload) { return true; }
    IPAddress remoteIP(uint8_t num) { return IPAddress(192, 168, 4, 2); }
};
