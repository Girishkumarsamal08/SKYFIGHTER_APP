#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string>
#include <cmath>
#include <algorithm>

#define HIGH 1
#define LOW 0

#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2

#define SERIAL_8N1 0x06

using std::isnan;
using std::min;

template<typename T>
inline T constrain(T amt, T low, T high) {
    return amt < low ? low : (amt > high ? high : amt);
}

class String : public std::string {
public:
    String() : std::string() {}
    String(const char* s) : std::string(s ? s : "") {}
    String(const std::string& s) : std::string(s) {}
    String(int v) : std::string(std::to_string(v)) {}
    String(double v, int digits = 2) : std::string(std::to_string(v)) {}
    String(float v, int digits = 2) : std::string(std::to_string(v)) {}
    
    int toInt() const { try { return std::stoi(*this); } catch (...) { return 0; } }
    float toFloat() const { try { return std::stof(*this); } catch (...) { return 0.0f; } }
    double toDouble() const { try { return std::stod(*this); } catch (...) { return 0.0; } }
    
    char charAt(size_t index) const { return index < length() ? (*this)[index] : 0; }
    
    String substring(size_t start, size_t end = std::string::npos) const {
        if (start >= length()) return String("");
        if (end == std::string::npos || end > length()) return String(substr(start));
        return String(substr(start, end - start));
    }
    
    bool startsWith(const char* prefix) const {
        if (!prefix) return false;
        std::string p(prefix);
        return length() >= p.length() && compare(0, p.length(), p) == 0;
    }

    bool endsWith(const char* suffix) const {
        if (!suffix) return false;
        std::string s(suffix);
        return length() >= s.length() && compare(length() - s.length(), s.length(), s) == 0;
    }
    
    String& operator+=(char c) { append(1, c); return *this; }
    String& operator+=(const char* s) { if (s) append(s); return *this; }
    void trim() {
        while (!empty() && isspace(back())) pop_back();
        size_t start = 0;
        while (start < length() && isspace((*this)[start])) start++;
        if (start > 0) erase(0, start);
    }
};

class IPAddress {
public:
    uint8_t bytes[4];
    IPAddress(uint8_t a = 0, uint8_t b = 0, uint8_t c = 0, uint8_t d = 0) {
        bytes[0] = a; bytes[1] = b; bytes[2] = c; bytes[3] = d;
    }
    String toString() const {
        return String(std::to_string(bytes[0]) + "." + std::to_string(bytes[1]) + "." + std::to_string(bytes[2]) + "." + std::to_string(bytes[3]));
    }
};

class HardwareSerial {
public:
    HardwareSerial(int uart_nr = 0) {}
    void begin(unsigned long baud, uint32_t config = 0, int rxPin = -1, int txPin = -1) {}
    int available() { return 0; }
    char read() { return 0; }
    String readStringUntil(char terminator) { return String(""); }
    
    void print(const String& s) {}
    void print(const char* s) {}
    void print(int n, int base = 10) {}
    void print(double n, int digits = 2) {}
    
    void println() {}
    void println(const String& s) {}
    void println(const char* s) {}
    void println(int n, int base = 10) {}
    void println(double n, int digits = 2) {}

    template<typename... Args>
    void printf(const char* format, Args... args) {}
};

extern HardwareSerial Serial;
extern HardwareSerial Serial1;
extern HardwareSerial Serial2;

void pinMode(uint8_t pin, uint8_t mode);
void digitalWrite(uint8_t pin, uint8_t val);
int digitalRead(uint8_t pin);
int analogRead(uint8_t pin);
void analogReadResolution(int bits);
unsigned long millis();
void delay(unsigned long ms);
