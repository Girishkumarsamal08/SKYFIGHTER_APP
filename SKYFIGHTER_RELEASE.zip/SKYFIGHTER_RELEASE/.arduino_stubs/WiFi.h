#pragma once
#include "Arduino.h"

enum WiFiMode_t {
    WIFI_OFF = 0,
    WIFI_STA = 1,
    WIFI_AP = 2,
    WIFI_AP_STA = 3
};

class WiFiClass {
public:
    bool mode(WiFiMode_t m) { return true; }
    bool softAPConfig(IPAddress local_ip, IPAddress gateway, IPAddress subnet) { return true; }
    bool softAP(const char* ssid, const char* passphrase = nullptr, int channel = 1, int ssid_hidden = 0, int max_connection = 4) { return true; }
    IPAddress softAPIP() { return IPAddress(192, 168, 4, 1); }
};

extern WiFiClass WiFi;
