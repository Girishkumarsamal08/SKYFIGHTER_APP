#pragma once
#include "Arduino.h"
#include <map>
#include <vector>

class JsonVariant {
public:
    JsonVariant() {}
    template<typename T>
    JsonVariant& operator=(const T& val) { return *this; }
    template<typename T>
    T operator|(const T& fallback) const { return fallback; }
    const char* operator|(const char* fallback) const { return fallback; }
    template<typename T>
    operator T() const { return T(); }
    operator const char*() const { return ""; }
};

class JsonArray {
public:
    JsonArray() {}
    class JsonObject createNestedObject();
    void add(const JsonVariant& v) {}
};

class JsonObject {
public:
    JsonObject() {}
    JsonVariant operator[](const char* key) const { return JsonVariant(); }
    JsonVariant& operator[](const char* key) { 
        static JsonVariant v; 
        return v; 
    }
    JsonObject createNestedObject(const char* key) { return JsonObject(); }
    JsonArray createNestedArray(const char* key) { return JsonArray(); }
};

inline JsonObject JsonArray::createNestedObject() { return JsonObject(); }

template<size_t Capacity>
class StaticJsonDocument : public JsonObject {
public:
    StaticJsonDocument() {}
};

class DeserializationError {
public:
    enum Code { Ok, EmptyInput, IncompleteInput, InvalidInput, NoMemory, TooDeep };
    Code code() const { return Ok; }
    const char* c_str() const { return "Ok"; }
    bool operator!() const { return true; }
    explicit operator bool() const { return false; }
};

inline String serialized(const String& s) { return s; }
inline String serialized(const char* s) { return String(s); }

template<typename T>
inline size_t serializeJson(const T& doc, String& out) {
    out = "{}";
    return out.length();
}

template<typename T>
inline size_t serializeJson(const T& doc, HardwareSerial& out) {
    out.println("{}");
    return 2;
}

template<typename T>
inline DeserializationError deserializeJson(T& doc, const uint8_t* input, size_t length) {
    return DeserializationError();
}

template<typename T>
inline DeserializationError deserializeJson(T& doc, const char* input, size_t length) {
    return DeserializationError();
}

template<typename T>
inline DeserializationError deserializeJson(T& doc, const char* input) {
    return DeserializationError();
}

template<typename T>
inline DeserializationError deserializeJson(T& doc, const String& input) {
    return DeserializationError();
}
